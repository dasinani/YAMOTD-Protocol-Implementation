import socket
import sys

if len(sys.argv) != 2:
    print("Usage: python client.py <server_ip>")
    sys.exit(1)

# Server details
SERVER_HOST = sys.argv[1]
SERVER_PORT = 26310

# Create a TCP socket
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect((SERVER_HOST, SERVER_PORT))  # Connect to server

message = "Hello, TCP Server!"

while True:
    command = input("Enter command (MSGGET, MSGSTORE, QUIT, SHUTDOWN): ").strip()
    client_socket.sendall((command + "\n").encode())

    if command == "MSGGET":
        response = client_socket.recv(1024).decode()
        print(f"Client: {command}")
        print(f"{response.strip()}")

        if response.strip() == "Server: 200 OK":
            motd = client_socket.recv(1024).decode()
            print(f"{motd.strip()}")

    elif command == "MSGSTORE":
        response = client_socket.recv(1024).decode()
        print(f"Client: {command}")
        print(f"{response.strip()}")

        if response.strip() == "Server: 200 OK":
            new_message = input("Enter new message of the day: ").strip()
            client_socket.sendall((new_message + "\n").encode())
            print(f"Client: {new_message}")
            final_response = client_socket.recv(1024).decode()
            print(f"{final_response.strip()}")

    elif command == "QUIT":
        response = client_socket.recv(1024).decode()
        print(f"Client: {command}")
        print(f"{response.strip()}")
        break

    elif command == "SHUTDOWN":
        response = client_socket.recv(1024).decode()
        print(f"Client: {command}")
        print(f"{response.strip()}")

        if response.strip() == "Server: 300 PASSWORD REQUIRED":
            password = input("Enter shutdown password: ").strip()
            print(f"Client: {password}")
            client_socket.sendall((password + "\n").encode())
            result = client_socket.recv(1024).decode()
            print(f"{result.strip()}")

            if result.strip() == "Server: 200 OKAY":
                break
           # else:
                #print("Unexpected response or shutdown denied")

        else:
            response = client_socket.recv(1024).decode()
            print(f"Client: {command}")
            print(f"{response.strip()}")

    else:
        response = client_socket.recv(1024).decode()
        print(f"Client: {command}")
        print(f"{response.strip()}")





#client_socket.sendall(message.encode())  # Send message

#data = client_socket.recv(1024).decode()  # Receive response
#print(f"Server replied: {data}")

client_socket.close()