import socket

# Server configuration
HOST = "127.0.0.1"
PORT = 26310

default_message = "An apple a day keeps the doctor away.\n"
default_password = "123!abc"

motd = default_message

# Create a TCP socket
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind((HOST, PORT))
server_socket.listen(5)

print(f"TCP Server is listening on {HOST}:{PORT}")

while True:
    conn, addr = server_socket.accept()  # Accept connection from client
    print(f"Connected by {addr}")
    waiting_for_msgstore = False

    try:
        while True:
            data = conn.recv(1024).decode().strip()  # Receive data (command)

            if not data:
                continue 

            print(f"Received:from {addr}: {data}")

            if waiting_for_msgstore:
                if data in ["MSGGET", "MSGSTORE", "SHUTDOWN", "QUIT"]:
                    conn.sendall("Server: EXPECTED MOTD, RECEIVED COMMAND\n".encode())
                    waiting_for_msgstore = False
                    continue
                motd = data + '\n'
                conn.sendall("Server: 200 OK\n".encode())
                print(f"Server: MOTD updated to: {motd.strip()}")
                waiting_for_msgstore = False
                continue

            elif data == "MSGGET":
                conn.sendall("Server: 200 OK\n".encode())
                conn.sendall(motd.encode())

            elif data == "MSGSTORE":
                conn.sendall("Server: 200 OK\n".encode())
                waiting_for_msgstore = True

            elif data == "QUIT":
                conn.sendall("Server: 200 OK\n".encode())
                break

            elif data == "SHUTDOWN":
                conn.sendall("Server: 300 PASSWORD REQUIRED\n".encode())
                password = conn.recv(1024).decode().strip()

                if password == default_password:
                    conn.sendall("Server: 200 OKAY\n".encode())
                    print("Server Password accepted. Shutting down")
                    conn.close()
                    server_socket.close()
                    exit(0)
                else:
                    conn.sendall("Server: 301 WRONG PASSWORD\n".encode())

            else:
                conn.sendall("Server: 400 UNKNOWN COMMAND\n".encode())



    except Exception as e:
        print(f"[!] Error: {e}")

    finally:
        conn.close()
        print(f"[-] Connection closed with {addr}")



            #response = f"Hello Client, I received: {data}"
            #conn.sendall(response.encode())  # Send response

            #conn.close()  # Close the connection
